
# Instagram clone using MERN stack

This is the frontend repo built with React. If you are looking for the backend repo : https://github.com/yassinjouao/instagram-clone-backend

https://github.com/yassinjouao/instagram-clone-frontend/assets/44931090/5a6b7d41-d913-4eee-8254-014731e369a8

## Authors

- [@yassinjouao](https://github.com/yassinjouao)



